package com.emp.controller;

import com.emp.entity.Employee;
import com.emp.service.IEmployeeService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;

// 使用Controller注解
@Controller
@RequestMapping("test")
public class ControllerTest {
    // 使用employeeServiceImpl
    @Resource
    private IEmployeeService employeeService;

    @RequestMapping("getEmp")
    public @ResponseBody
    Employee getEmp(String id) {
        return employeeService.findById(id);
    }
}
