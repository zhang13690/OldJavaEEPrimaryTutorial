package com.emp.service;

import com.emp.entity.Employee;

public interface IEmployeeService {
    Employee findById(String id);
}