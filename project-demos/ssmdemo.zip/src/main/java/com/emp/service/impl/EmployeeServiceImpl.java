package com.emp.service.impl;

import com.emp.entity.Employee;
import com.emp.entity.EmployeeExample;
import com.emp.mapper.EmployeeMapper;
import com.emp.service.IEmployeeService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.Resource;
import java.util.List;

// 使用Service注解
@Service
public class EmployeeServiceImpl implements IEmployeeService {
    // 使用注解使用mapper的bean
    @Resource
    private EmployeeMapper employeeMapper;

    @Override
    @Transactional(readOnly = true)
    public Employee findById(String id) {
        return employeeMapper.selectByPrimaryKey(id);
    }
}
